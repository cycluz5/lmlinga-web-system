# CLAUDE REVIEW MANIFEST

## Scope

Health Records → Risk Assessment

## Review stage

Final independent review before Production Freeze

**Not** Production Frozen.

## Production files included

### Health Records listing (primary)

- `resources/views/pages/health-records/risk-assessment.blade.php`
- `resources/css/pages/health-records-risk-assessment.css`
- `resources/js/pages/health-records-risk-assessment.js`
- `app/Support/HealthRecordsRiskAssessment.php`
- `app/Http/Controllers/HealthRecords/RiskAssessmentSummaryController.php`

### Eligibility / resident source dependencies

- `app/Support/DemoCatalog.php`
- `resources/demo/households.php`

### Household Profiling History / View / Edit / Date Filter (regression)

- `app/Http/Controllers/HouseholdProfiling/RiskAssessmentHistoryController.php`
- `app/Support/DemoRiskAssessment.php`
- `app/Http/Requests/UpdateRiskAssessmentSectionRequest.php`
- `resources/demo/risk-assessments.php`
- `resources/views/pages/household-profiling/risk-assessment-history.blade.php`
- `resources/views/pages/household-profiling/risk-assessment-show.blade.php`
- `resources/views/pages/household-profiling/risk-assessment-form.blade.php`
- `resources/views/pages/household-profiling/risk-assessment-section.blade.php`
- `resources/views/pages/household-profiling/partials/risk-assessment-member-card.blade.php`
- `resources/js/pages/risk-assessment.js`
- `resources/css/pages/risk-assessment.css`

### Sidebar / navigation

- `resources/views/components/lml/dashboard/sidebar.blade.php`
- `resources/views/components/lml/dashboard/sidebar-collapse-children.blade.php`
- `resources/js/pages/dashboard-sidebar.js`
- `app/Support/UiRole.php`

### Routes / asset entrypoints

- `routes/web.php`
- `resources/css/app.css`
- `resources/js/app.js`

## Test files included

- `tests/Feature/HealthRecordsRiskAssessmentTest.php`
- `tests/Feature/HouseholdProfilingRiskAssessmentTest.php`
- `tests/Feature/HouseholdProfilingRiskAssessmentHistoryViewEditTest.php`
- `tests/Feature/HealthRecordsSidebarNavigationTest.php`
- `tests/js/risk-assessment.test.mjs`
- `tests/js/dashboard-sidebar.test.mjs`

## Evidence included

### Final alignment (primary)

- `docs/qa/screenshots/health-records-risk-assessment-final-alignment/risk-assessment-1440x900-final-alignment.png`
- `docs/qa/screenshots/health-records-risk-assessment-final-alignment/risk-assessment-820x1180-final-alignment.png`
- `docs/qa/screenshots/health-records-risk-assessment-final-alignment/risk-assessment-390x844-final-alignment.png`
- `docs/qa/screenshots/health-records-risk-assessment-final-alignment/risk-assessment-1440x900-header-crop.png`
- `docs/qa/screenshots/health-records-risk-assessment-final-alignment/layout-measurements.json`

### Header-separator prior evidence

- `docs/qa/screenshots/health-records-risk-assessment-header-separator/risk-assessment-1440x900-header-separator.png`
- `docs/qa/screenshots/health-records-risk-assessment-header-separator/risk-assessment-820x1180-header-separator.png`
- `docs/qa/screenshots/health-records-risk-assessment-header-separator/risk-assessment-390x844-header-separator.png`
- `docs/qa/screenshots/health-records-risk-assessment-header-separator/risk-assessment-1440x900-header-crop.png`
- `docs/qa/screenshots/health-records-risk-assessment-header-separator/layout-measurements.json`

## Figma reference

**Not included in ZIP** — no Figma reference image is stored in the repository. Must be attached separately to Claude.

## Final test evidence

Recorded from the final listing UI verification run (no re-execution during packaging):

| Test file | Exact command | Exit | Passed | Assertions |
|---|---|---|---|---|
| `tests/Feature/HealthRecordsRiskAssessmentTest.php` | `php vendor/bin/phpunit --testdox tests/Feature/HealthRecordsRiskAssessmentTest.php` | 0 | 18 | 191 |
| `tests/Feature/HouseholdProfilingRiskAssessmentTest.php` | `php vendor/bin/phpunit tests/Feature/HouseholdProfilingRiskAssessmentTest.php` | 0 | 20 | 168 |
| `tests/Feature/HouseholdProfilingRiskAssessmentHistoryViewEditTest.php` | `php vendor/bin/phpunit tests/Feature/HouseholdProfilingRiskAssessmentHistoryViewEditTest.php` | 0 | 17 | 82 |
| `tests/Feature/HealthRecordsSidebarNavigationTest.php` | `php vendor/bin/phpunit tests/Feature/HealthRecordsSidebarNavigationTest.php` | 0 | 14 | 197 |
| `tests/js/risk-assessment.test.mjs` + `tests/js/dashboard-sidebar.test.mjs` | `node --test tests/js/risk-assessment.test.mjs tests/js/dashboard-sidebar.test.mjs` | 0 | 15 | 11 RA + 4 sidebar |

## Build evidence

- Command: `npm run build`
- Exit code: `0`
- Result: Vite success

## Important Risk Assessment contracts

1. Only Household Profiling residents who have **reached age 19** are eligible for the Health Records Risk Assessment resident workflow.
2. Age **18** → excluded.
3. Day **before** the 19th birthday → excluded.
4. Exact **19th birthday** → included.
5. Age **> 19** → included.
6. Eligibility is derived from recorded **DOB / birthday**, not a stale stored age field.
7. Listing **Add** button is removed.
8. **Export Data** is retained (UI-phase toast; no download).
9. **Search / Zone / Year** filters are retained.
10. Desktop filter ratio approximately **40% / 30% / 30%** (Search / Zone / Year).
11. **Full Name** is wider than individual status columns.
12. **BMI Status → Chronic Disease** headers have title / options **horizontal** separators.
13. **Full Name** does **not** have that internal horizontal separator.
14. **Vertical** column borders are retained.
15. Household Profiling Risk Assessment **History / View / Edit** behavior must remain unchanged.
16. History **Date Filter** behavior must remain unchanged.
17. Non-residents are not part of this resident Risk Assessment listing workflow.

## Known limitations

1. Health Records listing remains **UI-phase**: rows are eligible-resident display rows with preview status vocabulary; not persisted clinical records.
2. Export Data is a UI-phase toast only (no download implementation).
3. Add is intentionally absent from the barangay listing; individual assessments remain under Household Profiling → member.
4. Summary card totals reflect the eligible demo-resident dataset (currently 8), not the Figma sample total of 60.
5. Figma reference image is **not** stored in-repo and must be attached separately for visual comparison.
6. Packaging did not re-run tests; final test/build evidence above is from the last completed verification before this package.

## Security / exclusion statement

Package excludes:

- `.env` / `.env.*`
- credentials / API keys / tokens / secrets
- `vendor/`
- `node_modules/`
- `.git/`
- storage logs / framework caches
- unrelated modules and unrelated QA artifacts

## Packaging integrity statement

No production implementation files were modified during packaging.

Allowed packaging-only artifacts:

- `docs/qa/review-packages/CLAUDE_REVIEW_MANIFEST.md`
- `docs/qa/review-packages/LMLinga_Health_Records_Risk_Assessment_Claude_Final_Review.zip`
